a=input("Enter first number")
b=input("Enyter second number")
c=input("Enter third number")
d=(int(a)+int(b)+int(c))/3
print("The average of three numbers is :")
print(float(d))