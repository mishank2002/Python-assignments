SID=input("Enter your SID")
Name=input("Enter your name")
Gender=input("Enter your Gender ")
Course_name=input("Enter your course name")
CGPA=float(input("Enter your CGPA"))
STUDENT=[SID,Name,Gender,Course_name,CGPA]
print(STUDENT)