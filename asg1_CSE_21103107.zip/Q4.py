marks=[]
for i in range(5): #for loop to take input 5 times
    marks.append(input("Enter marks of students"))
marks.sort()
print(marks)    